<p align="center">
<img src=https://img.shields.io/github/issues/logicguy1/Discord-Nitro-Gen-and-Checker?style=flat-square&logo=appveyor&color=informational />
<img src=https://img.shields.io/github/license/logicguy1/Discord-Nitro-Gen-and-Checker?style=flat-square&logo=appveyor&color=informational />
<img src=https://img.shields.io/github/stars/logicguy1/Discord-Nitro-Gen-and-Checker?style=flat-square&logo=appveyor&color=blue />
<img src=https://img.shields.io/github/forks/logicguy1/Discord-Nitro-Gen-and-Checker?style=flat-square&logo=appveyor&color=blue />
</p>

# Discord Nitro Generator + Checker
<p align="center">
<img src="example.png" />
</p>

## Usage
Download the project files and run `main.py`  
You will be prompted with 2 questions the first one being the amounts of codes to check, usally the more the better but this is up to you.  
The second prompt will ask you for a discord webhook url this is not needed as such but if your running it on a server this is a very good idea.

## Installation
The only requement that is currently needed is `discord_webhook` that can be installed using 
```
python3 -m pip install discord_webhook
```
on linux, and on windows it is 
```
py -3 -m pip install discord_webhook
```

---

*This code was developed in collaboration with [this discord server](https://discord.gg/AtpBtMUpHK) make sure to check them out*
